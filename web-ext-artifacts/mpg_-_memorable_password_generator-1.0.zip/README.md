# mpg-firefox-ext
Firefox extension of MPG - Memorable Password Generator
